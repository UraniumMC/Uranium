package net.minecraftforge.cauldron.inventory;

import net.minecraft.inventory.IInventory;

import org.bukkit.craftbukkit.inventory.CraftInventory;

public class CraftCustomInventory extends CraftInventory {

    public CraftCustomInventory(IInventory inventory) {
        super(inventory);
        // TODO Auto-generated constructor stub
    }

}
