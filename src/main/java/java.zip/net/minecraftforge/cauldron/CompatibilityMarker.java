package net.minecraftforge.cauldron;

public class CompatibilityMarker {

}
