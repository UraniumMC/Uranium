package net.minecraftforge.cauldron.configuration;

public class TileEntityWorldConfig extends WorldConfig
{
    public TileEntityWorldConfig(String worldName, ConfigBase configFile)
    {
        super(worldName, configFile);
    }
}
