package net.minecraftforge.cauldron.configuration;

public class EntityWorldConfig extends WorldConfig{

    public EntityWorldConfig(String worldName,ConfigBase configFile){
        super(worldName,configFile);
    }
}
