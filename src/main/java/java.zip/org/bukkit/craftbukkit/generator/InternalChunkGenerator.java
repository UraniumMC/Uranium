package org.bukkit.craftbukkit.generator;

import org.bukkit.generator.ChunkGenerator;

// Do not implement functions to this class, add to NormalChunkGenerator
public abstract class InternalChunkGenerator extends ChunkGenerator implements net.minecraft.world.chunk.IChunkProvider {
}
