package org.bukkit.craftbukkit.generator;


/**
 * This class is useless. Just fyi.
 */
public class NetherChunkGenerator extends NormalChunkGenerator {
    public NetherChunkGenerator(net.minecraft.world.World world, long seed) {
        super(world, seed);
    }
}
