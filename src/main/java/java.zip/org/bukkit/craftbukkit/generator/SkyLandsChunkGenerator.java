package org.bukkit.craftbukkit.generator;


/**
 * This class is useless. Just fyi.
 */
public class SkyLandsChunkGenerator extends NormalChunkGenerator {
    public SkyLandsChunkGenerator(net.minecraft.world.World world, long seed) {
        super(world, seed);
    }
}
